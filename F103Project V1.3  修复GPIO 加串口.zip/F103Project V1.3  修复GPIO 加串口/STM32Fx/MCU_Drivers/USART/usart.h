/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-January-2017
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */
  #ifndef __USART_H
  #define __USART_H
	
#include "include.h"


void UART_Init(u32 pclk2,u32 bound,u8 NVIC_PreemptionPriority,u8 NVIC_SubPriority);



  
  #endif
  
/******************* (C) COPYRIGHT 2016 HUALONG *****END OF FILE****/
