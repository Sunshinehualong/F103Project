/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-January-2017
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */
	
  #ifndef __EXIT_H
  #define __EXIT_H
	#include "include.h"
	
	#define   NVIC_GROUPS     2   //����NVIC����Ϊ2

#if  NVIC_GROUPS==2    					/*!< 2 bits for pre-emption priority ��ռ���ȼ�0~3�������
                                     2 bits for subpriority          ��Ӧ���ȼ�0~3�������*/
#define    URGENT_BREAK_0        0    //����
#define    KEY_BREAK_1           1    //�ؼ�
#define    MAJOR_BREAK_2         2    //��Ҫ
#define    COMMON_BREAK_3        3    //��ͨ

#endif
	
void EXTI_PA0_Config(void);	
void NVIC_Group_Config(u8 NVIC_PriorityGroup); //�����жϷ�������
void EXITx_Init(GPIO_TypeDef* GPIOx,u32 PINx,u8 EXTI_Trigger,u8 NVIC_PreemptionPriority,u8 NVIC_SubPriority);//�ⲿ�жϳ�ʼ��

  
  #endif
  
/******************* (C) COPYRIGHT 2016 HUALONG *****END OF FILE****/
