/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-January-2017
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */
  #ifndef  __SYSTEM_H
  #define  __SYSTEM_H
  
  #include "include.h"
	
	
void SysTick_Init(void);  //ϵͳ�δ�ʱ��SysTick ��������
void Delay_us( u32 nus); //Systick ʵ��us��ʱ
void Delay_ms( u32 nms); //Systick ʵ��us��ʱ
void NVIC_PriodConfig(u8 PreemptionPriority,u8 SubPriority,u8 NVIC_Channel,u8 NVIC_Group);//Ƕ���жϷ������������ȼ����� 
  
  
  #endif

/******************* (C) COPYRIGHT 2016 HUALONG *****END OF FILE****/
