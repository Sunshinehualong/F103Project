/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-February-2016
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */

#include "include.h"
int main(void)
{
 	u8 temp=0;
	SysTick_Init();
	LED_Init();
	UART_Init(72,115200,1,1);
	//EXITx_Init(GPIOA,PIN0,EXTI_Trigger_Falling,2,0);
	//EXTI_PA0_Config();
	//KEY_Init();
//	RCC ->APB2ENR |= 1<<2 ; //PA
//	GPIOA ->CRL &=0xFFFFFFF0;
//	GPIOA ->CRL |=0x00000008;
//	GPIOA ->ODR |=1<<0;
	
	
		while(1)
			{	 
				  temp++;
					LED1_Blink();
				  printf("12345 ���������ѧ @#��%����&*\r\n");
				  Delay_ms(300);
				 //USART1->DR = temp;
				  
			} 
}


