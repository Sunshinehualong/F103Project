/**
  ******************************************************************************
  * @file    LEDģ��
  * @author  Hua long
  * @version V2.1.0
  * @date    21-January-2017
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */
  #ifndef __LED_H
  #define __LED_H
  
  #include "include.h"
  
	/* *****************************************************
	**
	***	��ѧϰ�ķ���
	**
	
// ֱ�Ӳ����Ĵ����ķ�������IO 
#define	digitalHi(p,i)				{p->BSRR=i;}			//����Ϊ�ߵ�ƽ		
#define digitalLo(p,i)				{p->BRR	=i;}				//����͵�ƽ
#define digitalToggle(p,i)		{p->ODR ^=i;}			//�����ת״̬


// �������IO�ĺ� 
#define LED1_TOGGLE		digitalToggle(GPIOB,GPIO_Pin_0)
#define LED1_OFF			digitalHi(GPIOB,GPIO_Pin_0)
#define LED1_ON				digitalLo(GPIOB,GPIO_Pin_0)
	*******************************************************
	*/
	
  //#define LED1  PCout(13)
	 #define LED1  PAout(2)
	
 //#define LED1_Blink(void)   LED1=(PCin(13))?0:1
	#define LED1_Blink(void)   LED1=(PAin(2))?0:1
  
	
	void LED_Init(void);	//LED��ʼ�� PC13
	
  #endif
	
/******************* (C) COPYRIGHT 2016 HUALONG *****END OF FILE****/
