#ifndef __INCLUDE_H
#define __INCLUDE_H
/**
  ******************************************************************************
  * @file    include.h ͷ�ļ����� 
  * @author  Hua long
  * @version V2.1.0
  * @date    21-January-2017
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention �ر�ע�⣬ͷ�ļ�����ʱ�����������ظ�����
  * 
  *
  ******************************************************************************
  */
/*
*********************************************************************************************************
*		ͷ�ļ�
*********************************************************************************************************
*/
/*C��׼���ļ�*/
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdarg.h>
#include <math.h>

/* -------APP--Ӧ�ò������ͷ�ļ�--------------------------------*/
//#include "GUI.h"
//#include "my_system.h"

/* -------BSP--����Ӳ���������ͷ�ļ�--------------------------------*/
//#include "led.h"
//#include "key.h"
//#include "exist.h"
//#include "uincsend.h"
//#include "tft.h"
//#include "GP2Y1010AU.h"
//#include "step_motor.h"
//#include "sensor.h"
//#include "oled.h"
//#include "gsm.h"
//#include "BH1750FVI.h"
//#include "DHT11.h"
/* -------MCU_Drivers--Ƭ�����������ͷ�ļ�--------------------------------*/
//#include "system.h"
//#include "delay.h"
//#include "usart.h"
//#include "myiic.h"
//#include "usart_2.h"
//#include "timer.h"
//#include "spi.h"
//#include "DMA.h"
//#include "my_adc.h"
//#include "iwdg.h"
#endif
