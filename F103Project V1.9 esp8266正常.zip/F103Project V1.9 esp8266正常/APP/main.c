/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-February-2016
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */

#include "include.h"
extern u8 NRF_RX_BUF[];  //NRF24L01�������� ���ⲿ�ж�
extern u8 NRF_TX_BUF[];  //NRF24L01�������� ���ⲿ�ж�

int main(void)
{
 	u8 i=0,m=0;
	
	SysTick_Init();	
	LED_Init();
//	EXIT_Init();
	USART1_Init(72,115200,1,2);
//	TIMx_Config(36,TIM4,10,2,2);  //TIM4��ʱ10ms,���USART2�����ж�ƥ��
	TIMx_Config(36,TIM2,1000,2,2);  //��ͨ��ʱ1000ms����ִ������
	
	NRF24L01_Config();
	NRF24L01_RT_Init();

//	USART2_Init(36,115200,1,1);

	
//	Delay_ms(2000);
//	AP_Server_Config();
	//while(i!=0);
//	TCP_Server();


		while(1)
			{	 
				i++;
				Delay_ms(10);
				m=NRF_Rec(NRF_RX_BUF);
				if(m==0)
				{
					USART_StrSend(USART1,NRF_RX_BUF);
					NRF_Send_ACK(NRF_RX_BUF);
				}
				

				if(i>100)
				{
				//LED2_Blink();
				i=0;
				NRF_Send_Data(0xff);
			
				}
			} 
}


