/**
  ******************************************************************************
  * @file    .C 
  * @author  Hua long
  * @version V2.1.0
  * @date    18-February-2017
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */
  
#include "Yeelink.h"


/******************************************************************************/
/*           ȫ�ֱ���                        */
/******************************************************************************/  


const char *GET_CODE[7]={"GET /v1.0/device/16927/sensor/377650/datapoints HTTP/1.1\r\n",
									"Host: api.yeelink.net\r\n",
									"Accept: */*\r\n",
									"U-ApiKey: ad7d2938afd9858d3c072e0250fc9d44\r\n",
									"Content-Length: 0\r\n",
									"Content-Type: text/html; charset=UTF-8\r\n",
									"Connection: close\r\n\r\n"	
};

const char *POST_CODE[7]={"POST /v1.0/device/16927/sensor/29314/datapoints HTTP/1.1\r\n",
									"Host: api.yeelink.net\r\n",
									"Accept: */*\r\n",
									"U-ApiKey: ad7d2938afd9858d3c072e0250fc9d44\r\n",
									"Content-Length: 12\r\n",           
									"Content-Type: application/json;charset=utf-8\r\n",
									"Connection: close\r\n"	
						//		"\r\n{\"value\":20}\r\n"     //u8 12    float.1f  14
};

/******************************************************************************/
/*           �ӿں���                    */
/******************************************************************************/  


/**
  ******************************************************************************
  * @function 	�ϴ������豸�����ݵ������� 
  * @author  		Hua long
  *	@arguments	None
  *	@return			None
  *	@ATTENTION	
	*	�ϴ����ݵļ������Ӧ >10s 
  ******************************************************************************
  */
void Yeelink_Send_POST(void)
	{
		
		u8 *Device1_value;
		Device1_value = mymalloc(20);
		sprintf((char*)Device1_value,"\r\n{\"value\":%d}\r\n",System.temperature);
		printf(POST_CODE[0]);
		printf(POST_CODE[1]);
		printf(POST_CODE[2]);
		printf(POST_CODE[3]);
		printf(POST_CODE[4]);
		printf(POST_CODE[5]);
		printf(POST_CODE[6]);
		printf(Device1_value);
		myfree(Device1_value);
	}

/**
  ******************************************************************************
  * @function 	GETָ�� ��ѯ��������ǰLED����״̬
  * @author  		Hua long
  *	@arguments	None
  *	@return			None
  *	@ATTENTION	��������Ӧ̫�������Բ�ѯ����̫Ƶ��
  ******************************************************************************
  */
void Yeelink_Send_GET(void)
{
		printf(GET_CODE[0]);
		printf(GET_CODE[1]);
		printf(GET_CODE[2]);
		printf(GET_CODE[3]);
		printf(GET_CODE[4]);
		printf(GET_CODE[5]);
		printf(GET_CODE[6]);
}
  


/******************************************************************************/
/*           ���ú���                        */
/******************************************************************************/  
/**
  ******************************************************************************
  * @function 	GET Yeelink�˿��ص�״̬
  * @author  		Hua long
  *	@arguments	*buf  �����յ�������֡
  *	@return			�ƶ˿���״̬
  *	@ATTENTION	
	*	 WiFi���ڴ���1 �ϣ�ʹ�ô���һ�������ݵ�
  ******************************************************************************
  */
void GET_Keystatus(void)
{
	u8 Keysta;
	char *JSON;//respond ��JSON���׵�ַ
	cJSON *json , *json_value ; 		 
		if(USART1_Check("200 OK")  )   //˵���յ�������
			{
				JSON = strchr((const char *)USART1_RX_BUF,'{');
				json = cJSON_Parse((char*)JSON);  
				if (!json)    
					usart3_printf("POST Request\n");    
				else  
				{  
						// ��������ֵ  
						json_value = cJSON_GetObjectItem( json , "value");  
						if( json_value->type == cJSON_Number )  
						{  
								// ��valueint�л�ý��  
								Keysta = json_value->valueint;
							  if(Keysta)  LED2=0;
								else				LED2=1;
							  usart3_printf("GET Request\n"); 
								usart3_printf("value:%d\r\n",Keysta);  
						}  
						// �ͷ��ڴ�ռ�  
						cJSON_Delete(json);  
				}  		
			
		}
		else  //δ�յ�GET �� 200 OK Ӧ���ٷ�һ��
		{
			usart3_printf("Error information\r\n");
		}
		 

}
  

/******************* (C) COPYRIGHT 2016 HUALONG *****END OF FILE****/
