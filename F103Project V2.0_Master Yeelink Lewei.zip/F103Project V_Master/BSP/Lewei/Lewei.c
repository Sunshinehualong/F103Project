/**
  ******************************************************************************
  * @file    .C 
  * @author  Hua long
  * @version V2.1.0
  * @date    18-February-2017
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
POST /api/V1/gateway/Updatesensors/02 HTTP/1.1
userkey: afe8c596525747f49a3db2f6b7f69fa7 
Host: open.lewei50.com 
Content-Length: 51
Connection: close

[{"Name":"T1","Value":26},{"Name":"H1","Value":30}]

  *
  ******************************************************************************
  */


#include "Lewei.h"


/******************************************************************************/
/*           ȫ�ֱ���                        */
/******************************************************************************/  


const char *LEWEI_GET[7]={"GET /v1.0/device/16927/sensor/377650/datapoints HTTP/1.1\r\n",
									"Host: api.yeelink.net\r\n",
									"Accept: */*\r\n",
									"U-ApiKey: ad7d2938afd9858d3c072e0250fc9d44\r\n",
									"Content-Length: 0\r\n",
									"Content-Type: text/html; charset=UTF-8\r\n",
									"Connection: close\r\n\r\n"	
};

const char *LEWEI_POST[6]={"POST /api/V1/gateway/Updatesensors/02 HTTP/1.1\r\n",
									"userkey: afe8c596525747f49a3db2f6b7f69fa7\r\n",
									"Host: open.lewei50.com\r\n",
									"U-ApiKey: ad7d2938afd9858d3c072e0250fc9d44\r\n",
									"Content-Length: 51\r\n",           
									"Connection: close\r\n"	
						//		"\r\n{\"value\":20}\r\n"     //u8 12    float.1f  14
//	"[{\"Name\":\"T1\",\"Value\":26},{\"Name\":\"H1\",\"Value\":30}]"
	//[{"Name":"T1","Value":26},{"Name":"H1","Value":30}]
};

/******************************************************************************/
/*           �ӿں���                    */
/******************************************************************************/  


/**
  ******************************************************************************
  * @function 	�ϴ������豸�����ݵ������� 
  * @author  		Hua long
  *	@arguments	None
  *	@return			None
  *	@ATTENTION	
	*	�ϴ����ݵļ������Ӧ >10s 
  ******************************************************************************
  */
void Lewei_POST(void)
	{
		
		u8 *Device1_value;
		Device1_value = mymalloc(60);
		sprintf((char*)Device1_value,"\r\n[{\"Name\":\"T1\",\"Value\":%d},{\"Name\":\"H1\",\"Value\":%d}]\r\n",\
																							System.temperature,System.humidity);
		printf(LEWEI_POST[0]);
		printf(LEWEI_POST[1]);
		printf(LEWEI_POST[2]);
		printf(LEWEI_POST[3]);
		printf(LEWEI_POST[4]);
		printf(LEWEI_POST[5]);
		printf(Device1_value);
		myfree(Device1_value);
	}

/**
  ******************************************************************************
  * @function 	GETָ�� ��ѯ��������ǰLED����״̬
  * @author  		Hua long
  *	@arguments	None
  *	@return			None
  *	@ATTENTION	��������Ӧ̫�������Բ�ѯ����̫Ƶ��
  ******************************************************************************
  */
void Lewei_GET(void)
{
		printf(LEWEI_GET[0]);
		printf(LEWEI_GET[1]);
		printf(LEWEI_GET[2]);
		printf(LEWEI_GET[3]);
		printf(LEWEI_GET[4]);
		printf(LEWEI_GET[5]);
		printf(LEWEI_GET[6]);
}
  


/******************************************************************************/
/*           ���ú���                        */
/******************************************************************************/  
/**
  ******************************************************************************
  * @function 	GET Yeelink�˿��ص�״̬
  * @author  		Hua long
  *	@arguments	*buf  �����յ�������֡
  *	@return			�ƶ˿���״̬
  *	@ATTENTION	
	*	 WiFi���ڴ���1 �ϣ�ʹ�ô���һ�������ݵ�
  ******************************************************************************
  */

  

/******************* (C) COPYRIGHT 2016 HUALONG *****END OF FILE****/
