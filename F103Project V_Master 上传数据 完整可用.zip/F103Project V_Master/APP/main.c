/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-February-2016
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */

#include "include.h"
int main(void)
{
 	u8 i=0;

	SysTick_Init();	
	USART1_Init(72,115200,1,1);
	USART3_Init(36,115200,1,2);
	TIMx_Config(36,TIM3,80,0,2); //TIM3��ʱ10ms,���USART1�����ж�ƥ��
	TIMx_Status(TIM3,DISABLE);	//�ر�TIM3
//	TIMx_Config(36,TIM4,1000,0,2);	//��ͨ��ʱ1000ms����ִ������  
	
	
		
//	NRF24L01_Config();
//	NRF24L01_RT_Init();
	LED_Init();
	DS18B20_Init();
//	mem_init();				//��ʼ���ڴ��	

		while(1)
			{	 
				i++;
				Delay_ms(500);
				System.temperature = DS18B20_Get_Temp();
				Send_GET();
//				LED2_Blink();
				if(i==20)
				{			
					Delay_ms(1000);
					Send_POST();
					Delay_ms(1000);

				i=0;	
				}
			} 
}


