/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-February-2016
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */

#include "include.h"
int main(void)
{
 	u8 i=0;
	
	SysTick_Init();	
	LED_Init();
	USART1_Init(72,115200,1,2);
	TIMx_Config(36,TIM4,10,1,2);  //TIM4��ʱ10ms,���USART1�����ж�ƥ��
//	TIMx_Config(36,TIM2,1000,1,1);  	//��ͨ��ʱ1000ms����ִ������
	TIMx_Status(TIM4,DISABLE);	//�ر�TIM4	

	USART3_Init(36,115200,1,1);
//	mem_init();				//��ʼ���ڴ��	
		while(1)
			{	 
				i++;
				Delay_ms(300);
				if(i>2)
				{
					
				LED1_Blink();
				//printf("The present temperature=\r\n");
				DMA_Usart3_printf("The present temperature=\r\n");
				i=0;
				}
			} 
}


