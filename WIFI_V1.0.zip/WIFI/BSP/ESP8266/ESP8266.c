/**
  ******************************************************************************
  * @file    .C 
  * @author  Hua long
  * @version V2.1.0
  * @date    18-February-2017
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */
#include "ESP8266.h"
/******************************************************************************/
/*           ȫ�ֱ���                        */
/******************************************************************************/  
const char *GET_CODE[7]={"GET /v1.0/device/16927/sensor/377650/datapoints HTTP/1.1\r\n",
									"Host: api.yeelink.net\r\n",
									"Accept: */*\r\n",
									"U-ApiKey: ad7d2938afd9858d3c072e0250fc9d44\r\n",
									"Content-Length: 0\r\n",
									"Content-Type: text/html; charset=UTF-8\r\n",
									"Connection: close\r\n\r\n"	
};

const char *POST_CODE[7]={"POST /v1.0/device/16927/sensor/29314/datapoints HTTP/1.1\r\n",
									"Host: api.yeelink.net\r\n",
									"Accept: */*\r\n",
									"U-ApiKey: ad7d2938afd9858d3c072e0250fc9d44\r\n",
									"Content-Length: 12\r\n",
									"Content-Type: application/json;charset=utf-8\r\n",
									"Connection: close\r\n"	
						//		"\r\n{\"value\":20}\r\n"
};

/******************************************************************************/
/*           �ӿں���                    */
/******************************************************************************/  





/**
  ******************************************************************************
  * @function 	GETָ�� ��ѯ��������ǰLED����״̬
  * @author  		Hua long
  *	@arguments	None
  *	@return			None
  *	@ATTENTION	��������Ӧ̫�������Բ�ѯ����̫Ƶ��
  ******************************************************************************
  */
void Send_GET(void)
{
		printf(GET_CODE[0]);
		printf(GET_CODE[1]);
		printf(GET_CODE[2]);
		printf(GET_CODE[3]);
		printf(GET_CODE[4]);
		printf(GET_CODE[5]);
		printf(GET_CODE[6]);
}
  


/******************************************************************************/
/*           ���ú���                        */
/******************************************************************************/  
/**
  ******************************************************************************
  * @function 	GET Yeelink�˿��ص�״̬
  * @author  		Hua long
  *	@arguments	*buf  �����յ�������֡
  *	@return			�ƶ˿���״̬
  *	@ATTENTION	
	*	 WiFi���ڴ���1 �ϣ�ʹ�ô���һ�������ݵ�
  ******************************************************************************
  */
void GET_Cmd(void)
{
	char *data;
	u16 rlen;
	char *start,*end;
	u16  Start,End;
	if(USART1_RX_STA&0x8000)
	 {
		rlen=USART1_RX_STA&0X7FFF;	//�õ����ν��յ������ݳ���
		USART1_RX_BUF[rlen]= '\0';		//���ӽ����� 
		USART_StrSend(USART3,USART1_RX_BUF);	// ���Կ��յ���ʲô���� -->UART3
		 
		if(USART1_Check("scope") !=0)   //�յ��趨��Χָ��  !ע��WiFi��������ǰ׺
		{
				data = strchr((const char *)USART1_RX_BUF,'=');
			start=strtok(data+1,":");
				end  =strtok(NULL,",");
			Start=strtoul(start,0,0);
			End  =strtoul(end,0,0);
			
			printf("scope is form %s to %s\r\n",start,end);
			printf("scope is form %d to %d\r\n",Start,End);
			
			
		}
		else  //δ�յ�GET �� 200 OK Ӧ���ٷ�һ��
		{
			printf("Error information \r\n");
			
		}
		 
	  USART1_RX_STA = 0;
	 }
}
  

/******************* (C) COPYRIGHT 2016 HUALONG *****END OF FILE****/
