/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-February-2016
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */

#include "include.h"
//extern u8  DMASendBuf[64]={0};		//DMA����Դ����������
int main(void)
{
 	u8 i=0;
	SysTick_Init();
	LED_Init();
	UART_Init(72,115200,1,1);
	EXIT_Init();
	//KEY_Init();
//	for(i=0;i<64;i++)
//	  DMASendBuf[i] += i;
	DMA_TransEN(DMA1_Channel4, 64);
	
		while(1)
			{	 
//						temp=KEY_Scan(0);
//		if(temp)
//		{
//		switch(temp)
//		{
//			case KEY_NONE: 
//										break;
//			case WKUP_PRES: LED1_Blink();			        
//										break;
//			case KEY2_PRES: LED1_Blink();
//							      break;
//			case KEY3_PRES: 
//										break;	
//			default : 
//										break;
//	  }
//	 }
//				if(PAin(0) == 0) 
					
					LED2_Blink();
				  Delay_ms(500);
				 DMA_printf("jakjfalkjfdlka���������ѧjlkjf\r\n");
				//while(PAin(0) == 1);
	//			  printf("12345 ���������ѧ @#��%����&*\r\n");
				  //Delay_ms(50);
				 //USART1->DR = temp;
				  
			} 
}


