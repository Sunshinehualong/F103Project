/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-January-2017
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */
	
  #ifndef __EXIT_H
  #define __EXIT_H
	#include "include.h"

	
#define Rising  						0x01  //01������
#define Falling							0x02	//10�½���
#define Rising_Falling			0x03	//01�����غ��½���

void EXIT_Init(void);
void EXITx_Config(GPIO_PORTTypeDef GPIO_PORTx,GPIO_PINTypeDef GPIO_PINx,u8 EXTI_Trigger);

  #endif
  
/******************* (C) COPYRIGHT 2016 HUALONG *****END OF FILE****/
