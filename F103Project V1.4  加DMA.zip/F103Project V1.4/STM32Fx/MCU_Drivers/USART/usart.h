/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-January-2017
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */
  #ifndef __USART_H
  #define __USART_H
	
#include "include.h"


/******************************************************************************/
/*           �Ƿ�ʹ��DMA��ͨģʽ                        */
/******************************************************************************/
#define Usart_DMASendMode  1   

#define USART1_DR_Base  0x40013804		// 0x40013800 + 0x04 = 0x40013804
#define SENDBUFF_SIZE   1024

//UART_Init(72,115200,1,1);//PCLK2 72M bound 115200 ��ռ���ȼ�1�������ȼ�1
void UART_Init(u32 pclk2,u32 bound,u8 NVIC_PreemptionPriority,u8 NVIC_SubPriority);

void DMA_UART1SendInit(void);  //UART1_Send DMAģʽ��ʼ������ 
void DMA_printf(char* fmt,...);
  
  #endif
  
/******************* (C) COPYRIGHT 2016 HUALONG *****END OF FILE****/
