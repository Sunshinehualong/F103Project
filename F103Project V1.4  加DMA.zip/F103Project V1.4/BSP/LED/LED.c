/**
  ******************************************************************************
  * @file    LEDģ��
  * @author  Hua long
  * @version V2.1.0
  * @date    21-January-2017
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */
  #include "LED.h"
	
	
	
/**
  ******************************************************************************
  *	�� �� ��: LED_Init
  *	����˵��: LED�˿ں�ʱ�ӵĳ�ʼ�� 
  *	��    �Σ���
  *	�� �� ֵ: ��
  *	˵	  ����  ������ʱ�ӣ��ٶ˿ڣ���Ȼ��ʧ��  APB2 PC13
  *	ʱ	  �䣺  2017/1/4 
  ******************************************************************************
  */
  void LED_Init(void)
  {
				//ʱ��ʹ��	
	  RCC->APB2ENR |= RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOC;//RCC_APB2PeriphClockCmd
	  //LED1 PC13 
	  GPIO_Set( GPIOC,PIN13 ,GPIO_MODE_SPEED_50M ,GPIO_MODE_Out_PP);
		
//	  //LED1 PC13 
	  GPIO_Set( GPIOA,PIN2 ,GPIO_MODE_SPEED_50M ,GPIO_MODE_Out_PP);
		
  }

/******************* (C) COPYRIGHT 2016 HUALONG *****END OF FILE****/
