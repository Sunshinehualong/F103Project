/**
  ******************************************************************************
  * @file    .C 
  * @author  Hua long
  * @version V2.1.0
  * @date    18-February-2017
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */
  
#include "Yeelink.h"
//#include "include.h"

/******************************************************************************/
/*           ȫ�ֱ���                        */
/******************************************************************************/  
const char *POST_CODE[7]={"POST /v1.0/device/16927/sensor/29314/datapoints HTTP/1.1\r\n",
									"Host: api.yeelink.net\r\n",
									"Accept: */*\r\n",
									"U-ApiKey: ad7d2938afd9858d3c072e0250fc9d44\r\n",
									"Content-Length: 12\r\n",
									"Content-Type: application/json;charset=utf-8\r\n",
									"Connection: close\r\n"	
						//		"\r\n{\"value\":20}\r\n"
};


/******************************************************************************/
/*           �����ʼ�� ������                        */
/******************************************************************************/  


/**
  ******************************************************************************
  * @function 	
  * @author  		Hua long
  *	@arguments	
  *	@return			None
  *	@ATTENTION	
	*	
  ******************************************************************************
  */
void Upload_data(void)
	{
		u8 *Device1_value;
		Device1_value = mymalloc(20);
		sprintf((char*)Device1_value,"\r\n{\"value\":%d}\r\n",System.temperature);
		printf(POST_CODE[0]);
		printf(POST_CODE[1]);
		printf(POST_CODE[2]);
		printf(POST_CODE[3]);
		printf(POST_CODE[4]);
		printf(POST_CODE[5]);
		printf(POST_CODE[6]);
		printf(Device1_value);
		myfree(Device1_value);
	}


/******************************************************************************/
/*           ���ú���                        */
/******************************************************************************/  


  

  
/******************* (C) COPYRIGHT 2016 HUALONG *****END OF FILE****/
