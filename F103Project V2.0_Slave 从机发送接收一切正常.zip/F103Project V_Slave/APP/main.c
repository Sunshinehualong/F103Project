/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-February-2016
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */

#include "include.h"
extern u8 NRF_RX_BUF[]; 	 //NRF ���ջ�����
int main(void)
{
 	u8 i=0,m;
	
	SysTick_Init();	
	LED_Init();
	USART1_Init(72,115200,1,2);
//	TIMx_Config(36,TIM4,10,2,2);  //TIM4��ʱ10ms,���USART2�����ж�ƥ��
//	TIMx_Config(36,TIM2,100,2,2);  //��ͨ��ʱ1000ms����ִ������
	


	USART3_Init(36,115200,1,1);
	
	NRF24L01_Config();
  

//	mem_init();				//��ʼ���ڴ��	
		while(1)
			{	 
				i++;
				Delay_ms(20);
				
				if(NRF_Rec(NRF_RX_BUF)==0)
				{
					USART_StrSend(USART3,NRF_RX_BUF-1);
					LED2_Blink();
					
				}
				

				if(i>50)
				{
					//NRF_Send_Data(0xff);
					LED1_Blink();
				i=0;

//			
			}
			} 
}


