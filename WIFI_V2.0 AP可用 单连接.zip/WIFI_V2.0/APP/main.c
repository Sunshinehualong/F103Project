/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-February-2016
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */

#include "include.h"
int main(void)
{
 	u8 i=0;
	
	SysTick_Init();	
	LED_Init();
	USART1_Init(72,115200,1,2);
	USART3_Init(36,115200,1,1);
	TIMx_Config(36,TIM4,10,0,2);  //TIM4��ʱ10ms,���USART1�����ж�ƥ��
	TIMx_Status(TIM4,DISABLE);	//�ر�TIM4	
	TIMx_Config(36,TIM2,20,2,1);  	//��ͨ��ʱ1000ms����ִ������
	Delay_ms(1000);
	//AP_Server_Config();
	TCP_Server();
//	mem_init();				//��ʼ���ڴ��	
		while(1)
			{	 
				i++;
				Delay_ms(500);
				if(i>2)
				{
					
				//LED1_Blink();
				//printf("The present temperature=\r\n");
				usart3_printf("system running\r\n");
				i=0;
				}
			} 
}


