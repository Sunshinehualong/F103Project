/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *�������޸�ǰ������ļ��Ѿ�������һЩϵͳ�쳣 �Ľӿ�
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"


extern void TimingDelay_Decrement(void); //SysTick_Handler ��
/** @addtogroup STM32F10x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/



/******************************************************************************/
/*            Cortex-M3 �ж�ϵͳ                         */
/******************************************************************************/


/* ��ʱ���жϷ�����  -----------------------------------------------------------*/

/* ---------------------------------------------------------��ʱ���жϷ����� ---*/



/*�ⲿ�жϷ�����  -------------------------------------------------------------*/
void EXTI0_IRQHandler(void)
{
	if(EXTI_GetITStatus(EXTI_Line0) != RESET) //
	{
		LED1_Blink();
		EXTI_ClearITPendingBit(EXTI_Line0);    
	}  
}

void EXTI2_IRQHandler(void)
{
//	u8 i;
//	delay_ms(10);	//����
//	if(KEY2==0)	  
//	{	
//  PFout(10)=0;
//	PFout(9)=1;
//	for(i=20;i>0;i--)
//		{
//			 PFout(10)=~PFout(10);
//			 PFout(9)=~PFout(9);
//			 delay_ms(100);
//		}
//	}		 
//	 EXTI_ClearITPendingBit(EXTI_Line2);//���LINE2�ϵ��жϱ�־λ 
}

void EXTI9_5_IRQHandler(void)
{
}

void EXTI15_10_IRQHandler(void)
{
}

/* ---------------------------------------------------------��ʱ���жϷ�����---*/




/* �����жϷ����� ���� -----------------------------------------------------------*/
void USART1_IRQHandler(void)
{
  u8 res = 0;
	if(USART1->SR&(1<<5)) //���յ�����
	{	
		USART1->SR &= ~(1<<5); 			 //��ս����ж� ��־λ
		LED1_Blink();
	  res = USART1->DR;		
	  //My_Shell();
	}
}
void USART2_IRQHandler(void)
{
}

void USART3_IRQHandler(void)
{
}

void USART4_IRQHandler(void)
{
}

void USART5_IRQHandler(void)
{
}

void USART6_IRQHandler(void)
{
}
/* ---------------------------------------------------------------�����жϷ����� ���� */


/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
	
	
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
/**
  ******************************************************************************
  *	
  *	�� �� ��: SysTick_Handler  
  *	����˵��: ϵͳ�δ�ʱ����ʵ�ֶ�ʱ/ ��ʱ���� 
  *	��    �Σ���
  *	�� �� ֵ: ��
  *	˵	  ����  
  *	ʱ	  �䣺  2017/1/4 
  ******************************************************************************
  */
void SysTick_Handler(void)
{
	TimingDelay_Decrement();	
}




/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
