/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-February-2016
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */

#include "include.h"
extern u8  DMASendBuf[SENDBUFF_SIZE];		//DMA����Դ����������

int main(void)
{
 	u8 i=0;
	SysTick_Init();
	LED_Init();
	UART_Init(72,115200,1,1);
	EXIT_Init();
	//KEY_Init();
	ADC1_Init(3);
	ADC1_Start();
	Lcd_Init();
	Lcd_Clear(RED);
	Lcd_Clear(BLUE);
	Lcd_Clear(YELLOW);
	Lcd_Clear(GRAY0);	
	GUI_Display();        
		while(1)
			{	 
					
					LED2_Blink();
				  Delay_ms(2000);
					for(i=0;i<6;i++)
					{
					printf("ADC1 channel%d ADC is  %d    ",i, AD_Value[i]);
					printf("ADC1 channel%d voltalt  is  %.2f\r\n\r\n",i, (float)AD_Value[i]*3.3/4096);
					
					}
				  //DMA_printf("jakjfalkjfdlka���������ѧjlkjf\r\n");
			  	//while(PAin(0) == 1);
	//			  printf("12345 ���������ѧ @#��%����&*\r\n");
				  //Delay_ms(50);
				 //USART1->DR = temp;
				  
			} 
}


