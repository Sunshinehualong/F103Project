/**
  ******************************************************************************
  * @file    
  * @author  Hua long
  * @version V2.1.0
  * @date    21-January-2017
  * @brief   This file provides all the  **** functions.
  ******************************************************************************
  * @attention
  *
  *
  ******************************************************************************
  */
#include <stm32f10x.h>
#include "include.h"
#include "GPIO.h"
void Delay(u32 count);
int main(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE); //ʹ�� PC �˿�ʱ��
				
			GPIO_Set(RCC_APB2Periph_GPIOA,GPIOA,GPIO_Pin_2,3,0);
	
//		GPIO_InitTypeDef GPIO_InitStructure;
		
//		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13; //�˿�����
//		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //�������
//		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
//		GPIO_Init(GPIOC, &GPIO_InitStructure); 
//		GPIO_SetBits(GPIOC,GPIO_Pin_13); 
//		GPIO_Init(GPIOC, &GPIO_InitStructure); //�������
		while(1)
			{
					GPIO_ResetBits(GPIOA,GPIO_Pin_2);
					
					Delay(3000000);
					GPIO_SetBits(GPIOA,GPIO_Pin_2);
					
					Delay(3000000);
				
			} 
}
/* *****��������********** */
void Delay(u32 count)
{
	u32 i=0;
	for(;i<count;i++);
}

